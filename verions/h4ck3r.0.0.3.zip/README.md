# h4ck3r
a chrome/firefox extension/add-on for testing/encoding/decoing/hash and other daily tasks for a developer.
